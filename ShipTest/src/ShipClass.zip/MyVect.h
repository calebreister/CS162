#ifndef MYVECT_H
#define MYVECT_H

struct MyVect
{
    float x;
    float y;
};

#endif
